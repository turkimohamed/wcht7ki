# Vue 3 - Realtime Chat App

Live Demo: [Link](https://vue-chat-app-27d21.web.app/)

## Project setup

```
yarn install
```

### Compiles and hot-reloads for development

```
yarn serve
```

### Compiles and minifies for production

```
yarn build
```
