<!-- components/ChatGPT.vue -->
<template>
  <div>
    <div v-for="(message, index) in gptMessages" :key="index" class="gpt-message">
      {{ message }}
    </div>
    <!-- Button to trigger GPT test -->
    <button @click="sendMessageToGPT">Test GPT</button>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      gptMessages: [],
      userInput: 'Hello, GPT!', // Initial user input for testing
    };
  },
  methods: {
    async sendMessageToGPT() {
      try {
        const response = await axios.post(
          'https://api.openai.com/v1/engines/davinci-codex/completions',
          {
            prompt: this.userInput,
            max_tokens: 100,
          },
          {
            headers: {
              Authorization: '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', // Replace with your actual API key
              'Content-Type': 'application/json',
            },
          }
        );

        const gptResponse = response.data.choices[0].text;
        this.gptMessages.push(gptResponse);
      } catch (error) {
        console.error('Error calling GPT API:', error);
      }
    },
  },
};
</script>
